package com.sayeed.host20.uk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    private TextView mTxtQuestion;
    private Button btnTrue;
    private Button btnFalse;
    private int score;
    private int mQuestionIndex;
    private int mQuizQuestion;
    private TextView mQuizStats;
    private ProgressBar mProgressbas;
    private QuizModel[] questioncollection=new QuizModel[]{
            new QuizModel(R.string.q1,true),
            new QuizModel(R.string.q2,false),
            new QuizModel(R.string.q3,true),
            new QuizModel(R.string.q4,false),
            new QuizModel(R.string.q5,true),
            new QuizModel(R.string.q6,false),
            new QuizModel(R.string.q7,true),
            new QuizModel(R.string.q8,false),
            new QuizModel(R.string.q9,true),
            new QuizModel(R.string.q10,false)


    };
    final int userprogress=(int)Math.ceil(100/questioncollection.length);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mTxtQuestion=findViewById(R.id.textView);

        QuizModel q1=questioncollection[mQuestionIndex];

        mQuizQuestion=q1.getmQuestion();
        mTxtQuestion.setText(mQuizQuestion);
        mProgressbas=findViewById(R.id.quizPB);
        mQuizStats=findViewById(R.id.textView2);
         btnTrue=findViewById(R.id.btnTrue);


        btnTrue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    changeindex();
                    evaluateuseranswer(false);

            }
        });

         btnFalse=findViewById(R.id.btnFalse);
        btnFalse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    changeindex();
            }
        });
        //QuizModel model =new QuizModel(R.string.q1,true);

    }
    private void changeindex(){
        mQuestionIndex=(mQuestionIndex+1)%10;
        mQuizQuestion=questioncollection[mQuestionIndex].getmQuestion();
        mTxtQuestion.setText(mQuizQuestion);
        mProgressbas.incrementProgressBy(userprogress);
        mQuizStats.setText(score+" ");
    }
    private void evaluateuseranswer(boolean userGuess){
        boolean currentanswer=questioncollection[mQuestionIndex].isAnswer();
        if (currentanswer==userGuess){
            Toast.makeText(getApplicationContext(),R.string.correct_toast_message,Toast.LENGTH_SHORT).show();
            score++;
        }

        else {
            Toast.makeText(getApplicationContext(),R.string.incorrect_toast_message,Toast.LENGTH_SHORT).show();
        }
    }
}




