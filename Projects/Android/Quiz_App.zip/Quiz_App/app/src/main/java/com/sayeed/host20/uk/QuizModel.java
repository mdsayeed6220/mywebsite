package com.sayeed.host20.uk;

public class QuizModel {
    private int mQuestion;
    private boolean Answer;

    public QuizModel(int mQuestion, boolean answer) {
        this.mQuestion = mQuestion;
        Answer = answer;
    }

    public int getmQuestion() {
        return mQuestion;
    }

    public void setmQuestion(int mQuestion) {
        this.mQuestion = mQuestion;
    }

    public boolean isAnswer() {
        return Answer;
    }

    public void setAnswer(boolean answer) {
        Answer = answer;
    }


}
